---
demo:
    title: 'Demo: Deploying an ARM Template'
    module: 'Module 1: Exploring Azure Resource Manager'
---

# Demo: Deploying an ARM Template

## Instructions

1. Quisque dictum convallis metus, vitae vestibulum turpis dapibus non.

    1. Suspendisse commodo tempor convallis. 

    1. Nunc eget quam facilisis, imperdiet felis ut, blandit nibh. 

    1. Phasellus pulvinar ornare sem, ut imperdiet justo volutpat et.

1. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. 

1. Vestibulum hendrerit orci urna, non aliquet eros eleifend vitae. 

1. Curabitur nibh dui, vestibulum cursus neque commodo, aliquet accumsan risus. 

    ```
    Sed at malesuada orci, eu volutpat ex
    ```

1. In ac odio vulputate, faucibus lorem at, sagittis felis.

1. Fusce tincidunt sapien nec dolor congue facilisis lacinia quis urna.

    > **Note**: Ut feugiat est id ultrices gravida.

1. Phasellus urna lacus, luctus at suscipit vitae, maximus ac nisl. 

    - Morbi in tortor finibus, tempus dolor a, cursus lorem. 

    - Maecenas id risus pharetra, viverra elit quis, lacinia odio. 

    - Etiam rutrum pretium enim. 

1. Curabitur in pretium urna, nec ullamcorper diam. 
