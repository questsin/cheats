﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using Microsoft.Azure.Devices.Shared;
using Newtonsoft.Json;

namespace Globomantics.BandAgent
{
    class Program
    {
        private const string DeviceConnectionString =
            "HostName=ps-demo-hub.azure-devices.net;DeviceId=device-01;SharedAccessKey=RyWAluGf0ag7GQLwM3b2bX7np53CiafBXwLzSZ65BEY=";

        static async Task Main(string[] args)
        {
            Console.WriteLine("Initializing Band Agent...");

            var device = DeviceClient.CreateFromConnectionString(DeviceConnectionString);

            await device.OpenAsync();

            Console.WriteLine("Device is connected!");

            var twinProperties = new TwinCollection();
            twinProperties["connection.type"] = "wi-fi";
            twinProperties["connectionStrength"] = "full";

            await device.UpdateReportedPropertiesAsync(twinProperties);

            //var count = 1;
            //while (true)
            //{
            //    var telemetry = new Telemetry
            //    {
            //        Message = "Sending complex object...",
            //        StatusCode = count++
            //    };

            //    var telemetryJson = JsonConvert.SerializeObject(telemetry);

            //    var message = new Message(Encoding.ASCII.GetBytes(telemetryJson));

            //    await device.SendEventAsync(message);

            //    Console.WriteLine("Message sent to the cloud!");

            //    Thread.Sleep(2000);
            //}

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
