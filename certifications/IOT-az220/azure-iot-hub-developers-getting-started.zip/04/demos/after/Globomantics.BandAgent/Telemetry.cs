﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Globomantics.BandAgent
{
    class Telemetry
    {
        public string Message { get; set; }

        public int StatusCode { get; set; }
    }
}
