﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Globomantics.Common
{
    public enum StatusType
    {
        NotSpecified,
        Happy,
        Unhappy,
        Emergency
    }
}
